import { createFileRoute } from "@tanstack/react-router";
import ronneyRetrato from "@/assets/ronney-retrato.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Ronney Guimarães Belmont — Poeta e Escritor" },
      {
        name: "description",
        content:
          "Página oficial de Ronney Guimarães Belmont, poeta e escritor brasileiro. Sete livros entre poesia, reflexão e contos. Escrever é uma forma de autoconhecimento, expressão e entrega.",
      },
      { property: "og:title", content: "Ronney Guimarães Belmont — Poeta e Escritor" },
      {
        property: "og:description",
        content:
          "Sete livros entre poesia, reflexão e contos de um autor que escreve para transformar dor em palavra e silêncio em verso.",
      },
      { property: "og:type", content: "website" },
      { property: "og:locale", content: "pt_BR" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LandingPage,
});

type Livro = {
  titulo: string;
  subtitulo?: string;
  categoria: string;
  preco: string;
  capa: string;
  url: string;
  destaque?: boolean;
};

const livros: Livro[] = [
  {
    titulo: "Versando em Silêncio",
    subtitulo: "Uma pequena coletânea de poemas, da minha adolescência até a fase adulta",
    categoria: "Poesia",
    preco: "R$ 109,68",
    capa: `${import.meta.env.BASE_URL}capas/livro-versando-em-silencio.png`,
    url: "https://clubedeautores.com.br/livro/versando-em-silencio-3",
  },
  {
    titulo: "Quando a Alma Versar",
    subtitulo: "Confissões poéticas de um amor infinito",
    categoria: "Poesia",
    preco: "R$ 109,68",
    capa: `${import.meta.env.BASE_URL}capas/livro-quando-a-alma-versar.png`,
    url: "https://clubedeautores.com.br/livro/quando-a-alma-versar",
  },
  {
    titulo: "Coleção Sentires",
    subtitulo: "Onde o sentir se transforma em palavras",
    categoria: "Poesia",
    preco: "R$ 157,10",
    capa: `${import.meta.env.BASE_URL}capas/livro-colecao-sentires.png`,
    url: "https://clubedeautores.com.br/livro/colecao-sentires",
  },
  {
    titulo: "O Poder do Silêncio",
    subtitulo: "Uma jornada pela psicologia do silêncio",
    categoria: "Reflexão",
    preco: "R$ 93,69",
    capa: `${import.meta.env.BASE_URL}capas/livro-o-poder-do-silencio.png`,
    url: "https://clubedeautores.com.br/livro/o-poder-do-silencio-5",
    destaque: true,
  },
  {
    titulo: "Adolescência — Espelho de um Lar",
    subtitulo: "Como a casa é percebida pelos filhos",
    categoria: "Reflexão",
    preco: "R$ 105,16",
    capa: `${import.meta.env.BASE_URL}capas/livro-adolescencia.png`,
    url: "https://clubedeautores.com.br/livro/adolescencia-espelho-de-um-lar",
  },
  {
    titulo: "Quem Conta um Conto Comenta Dez Contos",
    subtitulo: "Entre histórias e poemas da infância a adolescência",
    categoria: "Contos",
    preco: "R$ 117,95",
    capa: `${import.meta.env.BASE_URL}capas/livro-quem-conta-um-conto.png`,
    url: "https://clubedeautores.com.br/livro/quem-conta-um-conto-comenta-dez-contos-2",
  },
  {
    titulo: "Ser um Corretor de Imóveis de Sucesso",
    subtitulo: "Mais do que vender imóveis é realizar sonhos!",
    categoria: "Negócios",
    preco: "R$ 103,61",
    capa: `${import.meta.env.BASE_URL}capas/livro-corretor-de-imoveis.png`,
    url: "https://clubedeautores.com.br/livro/ser-um-corretor-de-imoveis-de-sucesso-2",
  },
];

const redes = [
  { nome: "WhatsApp", label: "Fale comigo", href: "https://wa.me/5511993834008" },
  {
    nome: "Instagram",
    label: "@poeta.ronneybelmont",
    href: "https://www.instagram.com/poeta.ronneybelmont/",
  },
  {
    nome: "Facebook",
    label: "Poeta Ronney Belmont",
    href: "https://www.facebook.com/poetaronneybelmont",
  },
  { nome: "LinkedIn", label: "Ronney Belmont", href: "https://www.linkedin.com/in/ronneybelmont/" },
  {
    nome: "Spotify",
    label: "Playlist do autor",
    href: "https://open.spotify.com/playlist/3jX84qzFnKWMnPL2yRIKBD",
  },
  {
    nome: "TikTok",
    label: "@poeta.ronney.belm",
    href: "https://www.tiktok.com/@poeta.ronney.belm",
  },
];

function LandingPage() {
  return (
    <div className="min-h-screen bg-background font-body text-foreground">
      <Header />
      <main>
        <Hero />
        <Citacao />
        <Sobre />
        <Livros />
        <Manifesto />
        <Contato />
      </main>
      <Footer />
    </div>
  );
}

function Header() {
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-border bg-background/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <a href="#topo" className="font-display text-lg font-semibold tracking-wide">
          Ronney Guimarães Belmont <span className="font-display italic text-primary">· autor</span>
        </a>
        <nav className="hidden items-center gap-8 font-mono text-[0.68rem] uppercase tracking-[0.25em] text-muted-foreground md:flex">
          <a href="#sobre" className="transition-colors hover:text-primary">
            O Autor
          </a>
          <a href="#livros" className="transition-colors hover:text-primary">
            Livros
          </a>
          <a href="#contato" className="transition-colors hover:text-primary">
            Contato
          </a>
        </nav>
        <a
          href="#livros"
          className="border border-primary/60 px-4 py-2 font-mono text-[0.65rem] uppercase tracking-[0.25em] text-primary transition-colors hover:bg-primary hover:text-primary-foreground"
        >
          Ver livros
        </a>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section id="topo" className="relative overflow-hidden pt-32 pb-20 md:pt-44 md:pb-28">
      {/* brilho quente no canto, sutil */}
      <div
        aria-hidden
        className="pointer-events-none absolute -top-40 right-[-10%] h-[36rem] w-[36rem] rounded-full opacity-25"
        style={{
          background: "radial-gradient(closest-side, oklch(0.79 0.095 84 / 22%), transparent)",
        }}
      />
      <div className="mx-auto grid max-w-6xl items-center gap-14 px-6 lg:grid-cols-[1.2fr_1fr]">
        <div>
          <p className="eyebrow">poeta · escritor · brasileiro</p>
          <h1 className="mt-6 font-display text-5xl font-medium leading-[1.05] tracking-tight md:text-7xl">
            Poesia que atravessa
            <br />o <em className="italic text-primary">silêncio</em> e chega em você.
          </h1>
          <p className="mt-8 max-w-xl text-lg leading-relaxed text-muted-foreground">
            Sete livros publicados, entre poesia, reflexão e contos, de um autor que escreve para
            transformar dor em palavra e silêncio em verso.
          </p>
          <div className="mt-10 flex flex-wrap gap-4">
            <a
              href="#livros"
              className="bg-primary px-7 py-3.5 font-mono text-[0.7rem] uppercase tracking-[0.25em] text-primary-foreground transition-opacity hover:opacity-85"
            >
              Conhecer os livros
            </a>
            <a
              href="https://wa.me/5511993834008"
              target="_blank"
              rel="noreferrer"
              className="border border-border px-7 py-3.5 font-mono text-[0.7rem] uppercase tracking-[0.25em] text-foreground transition-colors hover:border-primary hover:text-primary"
            >
              Falar com o autor
            </a>
          </div>
          <div className="mt-14 grid max-w-lg grid-cols-3 gap-6 border-t border-border pt-8">
            <div>
              <p className="font-display text-3xl font-semibold text-primary">7</p>
              <p className="mt-1 font-mono text-[0.62rem] uppercase tracking-[0.2em] text-muted-foreground">
                livros publicados
              </p>
            </div>
            <div>
              <p className="font-display text-3xl font-semibold text-primary">3</p>
              <p className="mt-1 font-mono text-[0.62rem] uppercase tracking-[0.2em] text-muted-foreground">
                gêneros: poesia, contos e reflexão
              </p>
            </div>
            <div>
              <p className="font-display text-2xl font-semibold text-primary">
                @poeta.ronneybelmont
              </p>
              <p className="mt-1 font-mono text-[0.62rem] uppercase tracking-[0.2em] text-muted-foreground">
                no Instagram
              </p>
            </div>
          </div>
        </div>
        <div className="relative mx-auto w-full max-w-sm">
          <div aria-hidden className="absolute -inset-3 border border-primary/30" />
          <img
            src={ronneyRetrato}
            alt="Retrato de Ronney Guimarães Belmont lendo um livro em sua biblioteca"
            className="w-full object-cover"
          />
          <p className="mt-6 text-center font-mono text-[0.62rem] uppercase tracking-[0.25em] text-muted-foreground">
            “Escrevo para me encontrar, para me entender e para me doar.”
          </p>
        </div>
      </div>
    </section>
  );
}

function Citacao() {
  return (
    <section className="border-y border-border bg-card py-16">
      <div className="mx-auto max-w-4xl px-6 text-center">
        <p className="font-display text-2xl font-medium italic leading-relaxed text-foreground md:text-3xl">
          “Sua literatura busca acolher sentimentos, provocar reflexões e lembrar que, mesmo nos
          momentos de silêncio, sempre existe algo dentro de nós esperando para se transformar em
          palavra.”
        </p>
      </div>
    </section>
  );
}

function Sobre() {
  return (
    <section id="sobre" className="py-24 md:py-32">
      <div className="mx-auto grid max-w-6xl gap-14 px-6 lg:grid-cols-[1fr_1.3fr]">
        <div>
          <p className="eyebrow">sobre o autor</p>
          <h2 className="mt-5 font-display text-4xl font-medium leading-tight md:text-5xl">
            Escrever é uma forma de autoconhecimento, expressão e entrega.
          </h2>
          <div className="rule-gold mt-8" />
        </div>
        <div className="space-y-6 text-lg leading-relaxed text-muted-foreground">
          <p>
            Ronney Guimarães Belmont é poeta e escritor brasileiro. Sua obra nasce da observação dos
            sentimentos humanos e transforma experiências de amor, dor, saudade, esperança e
            silêncio em palavras.
          </p>
          <p>
            Influenciado pela música e pela literatura clássica, desenvolve uma escrita marcada pela
            sensibilidade e pela reflexão. Seus textos percorrem diferentes fases da vida e convidam
            o leitor a olhar para dentro de si, reconhecer suas emoções e encontrar novos
            significados nas próprias experiências.
          </p>
          <p>
            Cada livro representa um fragmento de sua trajetória e uma ponte entre suas experiências
            e as histórias de seus leitores.
          </p>
        </div>
      </div>
    </section>
  );
}

function Livros() {
  const destaque = livros.find((l) => l.destaque)!;
  const demais = livros.filter((l) => !l.destaque);
  return (
    <section id="livros" className="border-t border-border bg-card py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-16 flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="eyebrow">obra completa</p>
            <h2 className="mt-5 font-display text-4xl font-medium md:text-5xl">
              Sete livros, um só silêncio
            </h2>
          </div>
          <a
            href="https://clubedeautores.com.br/livros/autores/ronney-guimaraes-belmont"
            target="_blank"
            rel="noreferrer"
            className="font-mono text-[0.65rem] uppercase tracking-[0.25em] text-primary underline-offset-4 hover:underline"
          >
            Ver perfil no Clube de Autores →
          </a>
        </div>

        {/* Livro em destaque */}
        <a
          href={destaque.url}
          target="_blank"
          rel="noreferrer"
          className="group mb-14 grid gap-10 border border-border bg-background p-8 transition-colors hover:border-primary/50 md:grid-cols-[220px_1fr] md:p-10"
        >
          <div className="relative">
            <img
              src={destaque.capa}
              alt={`Capa do livro ${destaque.titulo}`}
              className="w-full object-cover shadow-2xl shadow-black/50"
            />
          </div>
          <div className="flex flex-col justify-center">
            <p className="eyebrow">livro em destaque · {destaque.categoria}</p>
            <h3 className="mt-4 font-display text-3xl font-semibold md:text-4xl">
              {destaque.titulo}
            </h3>
            <p className="mt-3 max-w-xl text-muted-foreground">{destaque.subtitulo}</p>
            <div className="mt-6 flex flex-wrap items-center gap-6">
              <span className="font-display text-2xl font-semibold text-primary">
                {destaque.preco}
              </span>
              <span className="font-mono text-[0.65rem] uppercase tracking-[0.25em] text-muted-foreground group-hover:text-primary">
                Comprar no Clube de Autores →
              </span>
            </div>
          </div>
        </a>

        {/* Demais livros */}
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {demais.map((livro) => (
            <a
              key={livro.titulo}
              href={livro.url}
              target="_blank"
              rel="noreferrer"
              className="group flex flex-col border border-border bg-background p-6 transition-colors hover:border-primary/50"
            >
              <div className="relative overflow-hidden">
                <img
                  src={livro.capa}
                  alt={`Capa do livro ${livro.titulo}`}
                  className="w-full object-cover shadow-xl shadow-black/40 transition-transform duration-300 group-hover:scale-[1.02]"
                />
              </div>
              <p className="mt-6 font-mono text-[0.6rem] uppercase tracking-[0.25em] text-primary">
                {livro.categoria}
              </p>
              <h3 className="mt-2 font-display text-2xl font-semibold leading-snug">
                {livro.titulo}
              </h3>
              <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">
                {livro.subtitulo}
              </p>
              <div className="mt-5 flex items-center justify-between border-t border-border pt-4">
                <span className="font-display text-lg font-semibold text-foreground">
                  {livro.preco}
                </span>
                <span className="font-mono text-[0.6rem] uppercase tracking-[0.2em] text-muted-foreground group-hover:text-primary">
                  Comprar →
                </span>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

function Manifesto() {
  return (
    <section className="py-24 md:py-36">
      <div className="mx-auto max-w-3xl px-6 text-center">
        <div className="rule-gold mx-auto" />
        <p className="mt-10 font-display text-3xl font-medium italic leading-relaxed md:text-4xl">
          Para Ronney, cada livro é um fragmento de sua trajetória — e uma ponte entre as suas
          experiências e as <em className="text-primary">histórias de seus leitores</em>.
        </p>
        <a
          href="#livros"
          className="mt-10 inline-block border border-primary/60 px-7 py-3.5 font-mono text-[0.7rem] uppercase tracking-[0.25em] text-primary transition-colors hover:bg-primary hover:text-primary-foreground"
        >
          Escolher meu livro
        </a>
      </div>
    </section>
  );
}

function Contato() {
  return (
    <section id="contato" className="border-t border-border bg-card py-24">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-14 text-center">
          <p className="eyebrow">onde me encontrar</p>
          <h2 className="mt-5 font-display text-4xl font-medium md:text-5xl">Fale com o autor</h2>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {redes.map((rede) => (
            <a
              key={rede.nome}
              href={rede.href}
              target="_blank"
              rel="noreferrer"
              className="border border-border bg-background p-6 transition-colors hover:border-primary/60"
            >
              <p className="font-mono text-[0.62rem] uppercase tracking-[0.25em] text-primary">
                {rede.nome}
              </p>
              <p className="mt-2 text-sm text-foreground">{rede.label}</p>
            </a>
          ))}
        </div>
        <div className="mt-12 text-center">
          <a
            href="https://wa.me/5511993834008"
            target="_blank"
            rel="noreferrer"
            className="bg-primary px-8 py-4 font-mono text-[0.7rem] uppercase tracking-[0.25em] text-primary-foreground transition-opacity hover:opacity-85"
          >
            Chamar no WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border py-10">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-6 text-center md:flex-row md:text-left">
        <p className="font-display text-sm tracking-wide text-muted-foreground">
          Ronney Guimarães Belmont <span className="italic text-primary">· autor</span>
        </p>
        <p className="font-mono text-[0.6rem] uppercase tracking-[0.25em] text-muted-foreground">
          “mesmo no silêncio, algo espera para virar palavra”
        </p>
      </div>
    </footer>
  );
}
